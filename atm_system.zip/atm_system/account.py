import random
import os
import csv
import hashlib
import string


class Account:
    """Represents a bank account and handles its associated logic."""

    def __init__(self):
        """Create an Account object and ensure the file exists."""
        self.db_file = "account_balances.txt"
        self.headers = [
            "Account Number", "Phone Number", "PIN Hash", "Balance"
        ]
        self.__setup_file()

    def __setup_file(self):
        """Initialize account file with headers if missing."""
        if not os.path.exists(self.db_file):
            with open(self.db_file, 'w', newline="") as file:
                writer = csv.writer(file)
                writer.writerow(self.headers)

    def hash_pin(self, pin):
        """
        Hash the PIN using SHA-256.
        Chosen because it is a widely used and secure hashing algorithm
        providing a good balance between security and performance.
        """
        return hashlib.sha256(pin.encode()).hexdigest()

    def get_every_account(self):
        """Read all accounts from file and return as a list of dicts."""
        accounts = []
        with open(self.db_file, 'r', newline="") as file:
            reader = csv.DictReader(file)
            for row in reader:
                accounts.append(row)
        return accounts

    def save_every_account(self, accounts):
        """Write the list of account dictionaries back to the file."""
        with open(self.db_file, 'w', newline="") as file:
            writer = csv.DictWriter(file, fieldnames=self.headers)
            writer.writeheader()
            writer.writerows(accounts)

    def append_new_account(self, acc_num, phone, pin_hash, balance=0.0):
        """Append a newly registered account to the file."""
        with open(self.db_file, 'a', newline="") as file:
            writer = csv.writer(file)
            writer.writerow([acc_num, phone, pin_hash, balance])

    def phone_exists(self, phone_number):
        """Check if a phone number already exists in the accounts file."""
        for account in self.get_every_account():
            if account["Phone Number"] == phone_number:
                return True
        return False

    def generate_account_number(self):
        """
        Generate a unique 8-digit account number.
        Uses a while loop to ensure collisions are avoided.
        """
        accounts = self.get_every_account()
        existing_numbers = [acc["Account Number"] for acc in accounts]
        while True:
            acc_num = ''.join(random.choices(string.digits, k=8))
            if acc_num not in existing_numbers:
                return acc_num

    def authenticate(self, phone_number, pin):
        """Authenticate user by checking phone number and hashed PIN."""
        pin_hash = self.hash_pin(pin)
        for account in self.get_every_account():
            if (account["Phone Number"] == phone_number and
                    account["PIN Hash"] == pin_hash):
                return account
        return None

    def get_account_by_number(self, account_number):
        """Retrieve an account dictionary by its account number."""
        for account in self.get_every_account():
            if account["Account Number"] == account_number:
                return account
        return None

    def update_balance(self, phone_number, amount_delta):
        """Update balance by a given amount and save to file."""
        accounts = self.get_every_account()
        new_balance = 0.0

        for account in accounts:
            if account["Phone Number"] == phone_number:
                current_balance = float(account["Balance"])
                new_balance = current_balance + amount_delta
                account["Balance"] = str(new_balance)
                break

        self.save_every_account(accounts)
        return new_balance
