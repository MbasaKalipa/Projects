import sys
from account import Account
from transaction import TransactionManager


def main():
    """Run the main ATM application loop."""
    account_manager = Account()
    transaction_manager = TransactionManager()

    while True:
        print("\n==========================")
        print(" Welcome to PyBank ATM! ")
        print("==========================")
        print("1. Register")
        print("2. Login")
        print("3. Exit")

        choice = input("Select an option: ")

        if choice == '1':
            print("\n--- Account Registration ---")
            phone_number = input("Enter your phone number: (10 digits):  ")

            if len(phone_number) != 10 or not phone_number.isdigit():
                print("Invalid phone. Please enter a 10-digit number.")
                continue

            if account_manager.phone_exists(phone_number):
                print("Phone number already registered. Please login.")
                continue

            pin = input("Create a PIN (4-5 digits): ")
            if len(pin) < 4 or len(pin) > 5 or not pin.isdigit():
                print("Invalid PIN. Please enter a 4-5 digit number.")
                continue

            account_number = account_manager.generate_account_number()
            pin_hash = account_manager.hash_pin(pin)
            account_manager.append_new_account(
                account_number, phone_number, pin_hash
            )
            transaction_manager.log_event(phone_number, "REGISTERED")

            print("Registration successful.")
            print(f"Your account number is: {account_number}")
            print("Please save this number to receive transfers.")

        elif choice == '2':
            print("\n---Login ---")
            attempts = 0
            logged_in_user = None

            while attempts < 3:
                phone_number = input("Phone number: ")
                pin = input("PIN: ")

                logged_in_user = account_manager.authenticate(
                    phone_number, pin
                )

                if logged_in_user:
                    transaction_manager.log_event(phone_number, "LOGGED_IN")
                    print("\nLogin successful. Welcome back.")
                    break
                else:
                    attempts += 1
                    transaction_manager.log_event(phone_number, "FAILED_LOGIN")
                    print(f"Invalid credentials. Try again. ({attempts}/3)")

            if not logged_in_user:
                print("Too many failed login attempts. Exiting.")
                sys.exit()

            while True:
                # Refresh balance to ensure it is up-to-date
                user_data = account_manager.authenticate(phone_number, pin)
                current_balance = float(user_data["Balance"])

                print("\n--- Main Menu ---")
                print("1. Withdraw")
                print("2. Deposit")
                print("3. Transfer (EFT)")
                print("4. View Statement")
                print("5. Logout")

                user_choice = input("Select an option: ")

                if user_choice == '1':
                    try:
                        amount = float(input("Amount to withdraw: R "))
                        if amount <= 0:
                            print("Please enter a positive amount.")
                        elif amount > current_balance:
                            print("Insufficient funds for this withdrawal.")
                        else:
                            new_bal = account_manager.update_balance(
                                phone_number, -amount
                            )
                            transaction_manager.record_transaction(
                                phone_number, "WITHDRAWAL",
                                f"R{amount:.2f}", f"R{new_bal:.2f}"
                            )
                            print(f"Success. R{amount} withdrawn.")
                            print(f"New balance: R{new_bal:.2f}.")
                    except ValueError:
                        print("Error: Please enter a valid number.")

                elif user_choice == '2':
                    try:
                        amount = float(input("Amount to deposit: R "))
                        if amount <= 0:
                            print("Please enter an amount more than zero.")
                        else:
                            new_bal = account_manager.update_balance(
                                phone_number, amount
                            )
                            transaction_manager.record_transaction(
                                phone_number, "DEPOSIT",
                                f"R{amount:.2f}", f"R{new_bal:.2f}"
                            )
                            print(f"Success. R{amount} deposited.")
                            print(f"New balance: R{new_bal:.2f}.")
                    except ValueError:
                        print("Error: Please enter a valid number.")

                elif user_choice == '3':
                    print("\n--- EFT Transfer ---")

                    while True:
                        target_acc = input("Enter recipient (8 digits): ")

                        if len(target_acc) != 8 or not target_acc.isdigit():
                            print("Invalid. Enter an 8-digit number.")
                            continue

                        if target_acc == logged_in_user["Account Number"]:
                            print("Cannot transfer to your own account.")
                            continue

                        recipient = account_manager.get_account_by_number(
                            target_acc
                        )
                        if not recipient:
                            print("Account not found. Check and try again.")
                            continue
                        break

                    try:
                        amount = float(input("Amount to transfer: R "))
                        if amount <= 0:
                            print("Please enter an amount more than zero.")
                        elif amount > current_balance:
                            print("Insufficient funds for this transfer.")
                        else:
                            # Update sender
                            new_bal = account_manager.update_balance(
                                phone_number, -amount
                            )
                            transaction_manager.record_transaction(
                                phone_number, "EFT OUT",
                                f"R{amount:.2f}", f"R{new_bal:.2f}"
                            )

                            # Update recipient
                            rec_phone = recipient["Phone Number"]
                            rec_bal = account_manager.update_balance(
                                rec_phone, amount
                            )
                            transaction_manager.record_transaction(
                                rec_phone, "EFT IN",
                                f"R{amount:.2f}", f"R{rec_bal:.2f}"
                            )

                            print(f"Success. R{amount:.2f} sent.")
                            print(f"Your new balance is R{new_bal:.2f}.")
                    except ValueError:
                        print("Error: Please enter a valid number.")

                elif user_choice == '4':
                    print("\n---Statement ---")
                    statement = transaction_manager.get_statement(phone_number)
                    if not statement:
                        print("No transactions found.")
                    else:
                        for row in statement:
                            print(
                                f"{row['Timestamp']} | "
                                f"{row['Transaction_Type']} | "
                                f"Amount: {row['Amount']} | "
                                f"Balance: {row['Balance']}"
                            )

                elif user_choice == '5':
                    print("Logged out. Stay safe. ")
                    break

                else:
                    print("Invalid option. Select 1, 2, 3, 4 or 5.")

        elif choice == '3':
            print("Thank you for using PyBank ATM. Goodbye!")
            break

        else:
            print("Invalid option. Please select 1, 2 or 3.")


if __name__ == "__main__":
    main()
