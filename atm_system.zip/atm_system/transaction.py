import csv
import os
from datetime import datetime


class TransactionManager:
    """Manages reading and writing of transactions and logs."""

    def __init__(self):
        """Initialize TransactionManager and ensure files exist."""
        self.log_file = "log.txt"
        self.transaction_file = "transaction.txt"
        self._setup_files()

    def _setup_files(self):
        """Check if files exist; if not, create them with headers."""
        if not os.path.exists(self.log_file):
            with open(self.log_file, 'w', newline="") as file:
                writer = csv.writer(file)
                writer.writerow(["Timestamp", "Phone Number", "Event_Type"])

        if not os.path.exists(self.transaction_file):
            with open(self.transaction_file, 'w', newline="") as file:
                writer = csv.writer(file)
                writer.writerow([
                    "Timestamp", "Phone Number", "Transaction_Type",
                    "Amount", "Balance"
                ])

    def get_timestamp(self):
        """Return formatted current time for readability and CSVs."""
        now = datetime.now()
        return now.strftime("%Y-%m-%d %H:%M:%S")

    def log_event(self, phone_number, event_type):
        """Log events with timestamp, phone number, and event type."""
        with open(self.log_file, 'a', newline="") as file:
            writer = csv.writer(file)
            writer.writerow([self.get_timestamp(), phone_number, event_type])

    def record_transaction(self, phone, trans_type, amount, balance):
        """Record transaction with timestamp, type, amount, and balance."""
        with open(self.transaction_file, 'a', newline="") as file:
            writer = csv.writer(file)
            writer.writerow([
                self.get_timestamp(), phone, trans_type, amount, balance
            ])

    def get_statement(self, phone_number):
        """Retrieve the account statement for the logged-in user."""
        statement = []
        with open(self.transaction_file, 'r', newline="") as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row["Phone Number"] == phone_number:
                    statement.append(row)
        return statement
